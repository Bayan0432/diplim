<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">

	<script src="js/app.js" defer></script>

	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/sty.css">
	<title>Victory</title>
	
</head>
<body>
	<!-- LPTracker code start -->
<script type="text/javascript">
	(function() {
	var projectId = 107971;
	var script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = 'https://lpt-crm.online/lpt_widget/out/parser.min.js';
	window.lptWg = window.lptWg || {};
	window.lptWg.projectId = projectId;
	window.lptWg.parser = true;
	document.head.appendChild(script);
	})()
	</script>
	<script type="text/javascript">
	(function() {
	var projectId = 107971;
	var script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = 'https://lpt-crm.online/lpt_widget/kick-widget.js';
	window.lptWg = window.lptWg || {};
	window.lptWg.projectId = projectId;
	window.lptWg.parser = true;
	document.head.appendChild(script);
	})()
	</script>
	<!-- LPTracker code End -->
	<header class="header" id="header">
		<a class="header__logo logo">
			<img src="pictures/icons/logo1.png" width="125" height="40" alt="Shopiy logo">
		</a>

		<div class="burger-menu">
			<div class="burger-button">
        		<span></span>
      		</div>
		</div>

		<nav class="header-navigation navigation">

			<ul class="header-navigation__list navigation__list">
				<li class="header-navigation__item navigation__item">
					<a class="header-navigation__link navigation__link" href="#about">О нас</a>
				</li>
				<li class="header-navigation__item navigation__item">
					<a class="header-navigation__link navigation__link" href="#ysliga">Услуги</a>
				</li>
				<li class="header-navigation__item navigation__item">
					<a class="header-navigation__link navigation__link" href="#footer">Контакты</a>
				</li>
			</ul>

			<div class="header-user">
				<a href="#rep">
					<button class="user__sign-button button" type="button">Отправить заявку</button>
				</a>
				<a href="">
					<button class="user__free-button button" type="button">Консультация</button>
				</a>

			</div>
		</nav>
	</header>


	<main class="main">
		<div class="statuya" style="margin-left: 30%;" >
				<img class="power__illustration" src="pictures/illustration/femida.png"  alt="Photo of a man" style="position: absolute; width: 70% ;  ">
			</div>
		<section class="power container">
			
			<div class="power__text-content">
				<img class="power__cube" src="pictures/icons/cube-icon.svg" alt="Cube">
				<div class="power__text-content__inner">
					<div class="section-header section-power">
						<p class="section-header__suptitle power__garante">100% Сертифицированные услуги</p>
						<h1 class="section-header__subject power__subject" id="rep">Окажем юридические услуги</h1>
						<p class="section-header__subtitle power__suptitle">Приветствуем вас в нашем юридическом центре!Мы - команда высококвалифицированных юристов, готовых оказать вам качественную правовую поддержку в различных сферах.Более 5 лет наш юридический центр занимается оказанием услуг.</p>
					</div>
        		</div>
			
				<div>		
					<form id="myForm" action="#" method="post">
						<div class="power__forma forma">
							<label class="input__wrapper">Name: <input type="text" name="firstname" id="firstname" class="power__input forma__input" ></label><br>
							<label class="input__wrapper">Email: <input type="email" name="email" id="email" class="power__input forma__input"></label><br>
							<label class="input__wrapper">Phone number: <input type="tel" name="phone" id="phone" class="power__input forma__input"></label><br>
						</div>
						
						<button type="submit"  id="submitButton"  class="forma__button button">Send</button>

					
						<!-- Модальное окно -->
						<div id="myModal" class="modal">
							<div class="modal-content">
							  <p style="color: black;
							  padding-bottom: 40px;
							  font-size: 20px;">Вы можете связаться с нами в:</p>
							  <span class="close">&times;</span>
							  <a href="https://t.me/bayan_kenzheev" target="_blank" class="modal-button">Telegram</a>
							  <a href="https://wa.me/77051197115?text=" target="_blank" class="modal-button">WhatsApp</a>
							  <a href="mailto:bayan.kenzheev@yandex.ru"  target="_blank" class="modal-button" >Написать письмо</a>
							</div>
						</div>
					</form>
					<ul class="power-available__list">
						<li class="power-available__item">
							<img src="pictures/icons/check-mark-icon.png" width="30" height="30" alt="Check mark">
							<p class="power__item-text">Ответим в течении 2-х минут</p>
						</li>

						<li class="power-available__item">
							<img src="pictures/icons/check-mark-icon.png" width="30" height="30" alt="Check mark">
							<p class="power__item-text">Оплата после оказания услуги</p>
						</li>
					</ul>
				</div>
			</div>
			<div class="power__pictures-wrapper">
				
				<img class="power__triangle" src="pictures/icons/triangle-icon.png" alt="Triangle">
				<img class="power__cubeTwo" src="pictures/icons/cube-icon.svg" alt="Cube">
			</div>
				
		</section>

		




		<section class="build container" id="about">
			<div class="build__pictures-wrapper">
				<img class="build__pictures" src="pictures/illustration/Эстетика .jpg"alt="Phone illustration">
			</div>

			<div class="build__content">
				<div class="section-header build__section">
					<p class="section-header__suptitle build__suptitle">Гарантия качества</p>
					<h2 class="section-header__subject build__subject"> Мы каждый день помогаем людям решить свою проблему в сфере закона.</h2>
				</div>

				<ul class="statistic__list">
					<li class="statistic__item">
						<div class="statistic-count"><span>Опытные специалисты</span></div>
						<div class="statistic-info">Юристы и адвокаты с опытом работы в правоохранительных органах</div>
					</li>
					<li class="statistic__item">
						<div class="statistic-count">4000+</div>
						<div class="statistic-info">Довольных клиентов</div>
					</li>


				</ul>
			</div>
		</section>

		<section class="wedo container" id="ysliga">
			<div class="yslygi">
				<h1>Чем мы можем вам помочь</h1>
				<div class="katalog_yslug">
					<div class="content_cart">						
						<a class="content_yslug" href="yslyga1.html">
							<img class="bankrot" src="pictures/illustration/банкрот.jpg" alt="">
							<p>Банкротство</p>
							<h1>250000 тг</h1>
							<h2>Поможем оформить банкротство физ/юр лицам </h2>
						</a>
					</div>
					<div class="content_cart">						
						<a class="content_yslug" href="yslyga2.html">
							<img class="bankrot" src="pictures/illustration/Снять арест.png" alt="">
							<p>Снять арест со счетов </p>
							<h1>5000 тг</h1>
							<h2>Снимаем арест со счетов  </h2>
						</a>
					</div>
					<div class="content_cart">						
						<a class="content_yslug" href="yslyga3.html">
							<img class="bankrot" src="pictures/illustration/ocr.jpg" alt="">
							<p>Cнимаем запрет на выезд</p>
							<h1>50000 тг</h1>
							<h2>Помогаем получить график по Банкам второго уровня  </h2>
						</a>
					</div>
					<div class="content_cart">						
						<a class="content_yslug" href="yslyga4.html">
							<img class="bankrot" src="pictures/illustration/ocr (1).jpg" alt="">
							<p>График МФО </p>
							<h1>15000 тг</h1>
							<h2>Получить график МФО  </h2>
						</a>
					</div>
					
					
				</div>
			</div>
		</section>

		<section class="product container" style="display: flex;">
			<div style="display: flex;">
				<div class="product__pictures">
					<img class="product__foto" src="pictures/illustration/feature.jpg" alt="Product foto" style="width: 90%;
					border-radius: 50px;">	
				</div>

				<div class="product__content" style="
				background-color: white;
				border-radius: 10px;
				color: black;
				width: 52%;
				margin-left: -26%;
				margin-top: 6%;
				height: 75%;
				padding-left: 20px;
				Z-INDEX: 1;">
					<div class="section-header section-header-product">
						<!--<p class="section-header__suptitle product__suptitle">OUR PRODUCT STORIES</p>-->
						<h2 class="section-header__subject product__subject">Как это работает ?</h2>
					</div>

					<ul class="product-avaliable__list">
						<li class="product-avaliable__item">
							<h3 class="product-avaliable__subject">Вы выбираете специалиста</h3>
							<p class="product-avaliable__suptitle">Для вас только профессионалы своего дело.</p>
						</li>

						<li class="product-avaliable__item">
							<h3 class="product-avaliable__subject">Изучаете анкеты и отзывы о специалистах</h3>
							<p class="product-avaliable__suptitle">Фотографии, услуги, цены и только подлинные отзывы.</p>
						</li>

						<li class="product-avaliable__item">
							<h3 class="product-avaliable__subject">Звоните нам и получаете консультацию или услугу<h3>
							<p class="product-avaliable__suptitle">Проведем беседу онлайн или в офисе, заключим контракт.</p>
						</li>

					</ul>
				</div>
			</div>
			
		</section>

		<section class="section_new">
			
			<div class="content_new">
				<div class="Tema">
					<h1>Отзывы клиентов</h1>
				</div>
				<div class="otzivi_clientov">
					<div id="disqus_thread"></div>
<script>
    /**
    *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
    *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
    var d = document, s = d.createElement('script');
    s.src = 'https://victory-3.disqus.com/embed.js';
    s.setAttribute('data-timestamp', +new Date());
    (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
					
				</div>
			</div>
				</section>

				<section class="oprostnic">
					<div class="oprostnic__pictures-wrapper">
						<h1>Система опроса</h1>
					






					</div>
				</section>


		<footer class="new_footer_area bg_color" id="footer">
			<div class="new_footer_top">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-6" style="width: 30%;">
							<div class="f_widget company_widget wow fadeInLeft" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInLeft;">
								<h3 class="f-title f_600 t_color f_size_18">Наш офис</h3>
								<p>г.Петропавловск, ул. К. Сутюшева 60,
									БЦ «Квартал», 6 этаж, каб. 607</p>
								
							</div>
						</div>
						
						<div class="col-lg-3 col-md-6">
							<div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
								<h3 class="f-title f_600 t_color f_size_18">Навигации</h3>
								<ul class="list-unstyled f_list">
									<li><a href="#about">О нас</a></li>
									<li><a href="#ysliga">Наши услуги</a></li>
									<li><a href="#news">Полезная информация</a></li>
									<li><a href="#rep">Отправить заявку</a></li>
									<li><a href="#"></a></li>
									<li><a href="#"></a></li>
								</ul>
							</div>
						</div>
						<div class="col-lg-3 col-md-6">
							<div class="f_widget social-widget pl_70 wow fadeInLeft" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInLeft;">
								<h3 class="f-title f_600 t_color f_size_18">Контакты</h3>
								<div class="f_social_icon">
									<a href="#" class="fab fa-facebook" ><img src="pictures/social/facebook.png" alt=""></a>
									<a href="#" class="fab fa-twitter"><img src="pictures/social/twitter.png" alt=""></a>
									<a href="#" class="fab fa-linkedin"><img src="pictures/social/linkedin.png" alt=""></a>
									<a href="#" class="fab fa-pinterest"><img src="pictures/social/instagram.png" alt=""></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="footer_bg">
					<div class="footer_bg_one"></div>
					<div class="footer_bg_two"></div>
				</div>
			</div>
			<div class="footer_bottom">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-6 col-sm-7">
							<p class="mb-0 f_400">©  Victory. All Rights Reserved. Developed by students KU</p>
						</div>
						
					</div>
				</div>
			<a href="#header"><img src="pictures/icons/стрелка вверх.png" alt="" style="width: 25px;"></a>
			</div>
		</footer>
	</main>	
	<script id="dsq-count-scr" src="//victory-3.disqus.com/count.js" async></script>
	<script src="script.js"></script>
</body>
</html>