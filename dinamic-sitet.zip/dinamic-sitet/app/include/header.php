<head>
<link rel="stylesheet" href="assets/css/style1.css">
<link rel="stylesheet" href="assets/css/style2.css">

</head>


<header class="header" id="header">
    <div class="container">
        <div class="row">
			<img class="logo" src="assets/images/icons/logo1.png" width="125" height="40" alt="Shopiy logo">
            <nav class="header-navigation navigation">
                <ul  class="header-navigation__list navigation__list" >
                    <li class="header-navigation__item navigation__item"><a href="<?php echo BASE_URL ?>">Главная</a> </li>
                    <li class="header-navigation__item navigation__item"><a href="#">О нас</a> </li>
                    <li class="header-navigation__item navigation__item"><a href="#">Услуги</a> </li>

                    <li class="header-navigation__item navigation__item">
                        <?php if (isset($_SESSION['id'])): ?>
                            <a href="#">
                                <i class="fa fa-user"></i>
                                <?php echo $_SESSION['login']; ?>
                            </a>
                                <?php if ($_SESSION['admin']): ?>
                                    <li class="header-navigation__item navigation__item" ><a href="<?php echo BASE_URL . "admin/posts/index.php"; ?>"  > Для юристов</a> </li>
                                <?php endif; ?>
                                <li><a href="<?php echo BASE_URL . "logout.php"; ?>">Выход</a> </li>
                            
                        <?php else: ?>
                            <a href="<?php echo BASE_URL . "log.php"; ?>">
                                <i class="fa fa-user"></i>
                                Войти
                            </a>
                                <li  class="header-navigation__item navigation__item"><a href="<?php echo BASE_URL . "reg.php"; ?>">Регистрация</a> </li>
                        <?php endif; ?>

                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>