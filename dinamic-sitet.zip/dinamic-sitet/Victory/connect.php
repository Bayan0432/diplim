<?php
$dbc = mysqli_connect('localhost', 'root', '', 'Victory');

$data = json_decode(file_get_contents('php://input'), true);
$name = $data['name'];
$email = $data['email'];
$phone = $data['phone'];

$query = "INSERT INTO users (firstname, email, phone)
          VALUES ('$name', '$email', '$phone')";

$result = mysqli_query($dbc, $query);

http_response_code(201);
header('Content-type: application/json');
print json_encode(array('message' => 'Feedback has been sent'));

mysqli_close($dbc);
?>