# easy-php-cms
Simple content management system self-written on PHP7 (only function, not OOP)
