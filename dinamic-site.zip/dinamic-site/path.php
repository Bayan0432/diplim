<?php
const SITE_ROOT = __DIR__;
const BASE_URL = "http://localhost/dinamic-site/";
define("ROOT_PATH", realpath(dirname(__FILE__)));