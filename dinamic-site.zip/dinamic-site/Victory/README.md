<p align="center">
  <a href="https://itchief.ru/javascript/chatbot-for-website">
    <img alt="Простой чат-бот для сайта на чистом JavaScript" src="https://github.com/itchief/SimpleChatbot/raw/main/itchief_logo.png" width="75">
  </a>
</p>
<h1 align="center">
  SimpleChatbot
</h1>

#### Simple chatbot for website in pure JavaScript

## Status

![GitHub release (latest by date)](https://img.shields.io/github/v/release/itchief/SimpleChatbot)
![GitHub file size in bytes](https://img.shields.io/github/size/itchief/SimpleChatbot/chatbot/chatbot.js?label=chatbot.js)
