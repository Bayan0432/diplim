<?php

require_once 'vendor/autoload.php';

$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета на выезд.docx');

$uploadDir =  __DIR__;
$outputFile = 'Снятие запрета на выезд_full.docx';

$uploadFile = $uploadDir . '\\' . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile);

$name = $_POST['name'];
$organzapret = $_POST['organzapret'];
$date = $_POST['date'];
$namecountry = $_POST['namecountry'];
$prichinazapr = $_POST['prichinazapr'];
$obstoiatelstvo = $_POST['obstoiatelstvo'];
$obiasnenie = $_POST['obiasnenie'];
$tel = $_POST['tel'];
$gmail = $_POST['gmail'];
$file = $_POST['file'];


$document->setValue('name', $name);
$document->setValue('organzapret', $organzapret);
$document->setValue('date', $date);
$document->setValue('birth', $birth);
$document->setValue('namecountry', $namecountry);
$document->setValue('prichinazapr', $prichinazapr);
$document->setValue('obstoiatelstvo', $obstoiatelstvo);
$document->setValue('obiasnenie', $obiasnenie);
$document->setValue('tel', $tel);
$document->setValue('gmail', $gmail);
$document->setImageValue('image', array('path' => $uploadFile, 'width' => 120, 'height' => 120, 'ratio' => false));

$document->saveAs($outputFile);


// Имя скачиваемого файла
$downloadFile = $outputFile;

// Контент-тип означающий скачивание
header("Content-Type: application/octet-stream");

// Размер в байтах
header("Accept-Ranges: bytes");

// Размер файла
header("Content-Length: ".filesize($downloadFile));

// Расположение скачиваемого файла
header("Content-Disposition: attachment; filename=".$downloadFile);  

// Прочитать файл
readfile($downloadFile);


unlink($uploadFile);
unlink($outputFile);