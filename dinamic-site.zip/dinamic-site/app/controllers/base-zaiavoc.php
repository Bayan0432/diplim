<?php
include SITE_ROOT . "/app/database/db.php";
if (!$_SESSION){
    header('location: ' . BASE_URL . 'log.php');
}

$errMsg = [];
$id = '';
$title = '';
$content = '';
$file = ''; // Заменено поле на file
$topic = '';
$gmail = ''; // Добавлено новое поле для адреса Gmail
$number = ''; // Добавлено новое поле для номера телефона

$topics = selectAll('topics');
$base = selectAll('base');
$postsAdm = selectAllFromBaseWithUsers('base','users');

// Код для формы создания заявки
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_post'])){
    // Получение данных из формы
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $topic = trim($_POST['topic']);
    $publish = isset($_POST['publish']) ? 1 : 0;
    $gmail = trim($_POST['gmail']); // Получение адреса Gmail из формы
    $number = trim($_POST['number']); // Получение номера телефона из формы

    if (!empty($_FILES['file']['name'])){ // Заменено поле на file
        $fileName = time() . "_" . $_FILES['file']['name']; // Заменено поле на file
        $fileTmpName = $_FILES['file']['tmp_name']; // Заменено поле на file
        $destination = ROOT_PATH . "/assets/files/" . $fileName; // Заменено поле на file

        $result = move_uploaded_file($fileTmpName, $destination); // Заменено поле на file

        if ($result){
            $_POST['file'] = $fileName; // Заменено поле на file
        } else {
            array_push($errMsg, "Ошибка загрузки файла на сервер");
        }
    } else {
        // Если файл не выбран, установим значение пустой строки для file
        $_POST['file'] = ''; // Заменено поле на file
    }

    // Проверка заполнения всех полей и выполнение сохранения данных
    if($title === '' || $content === '' || $topic === '' || $gmail === '' || $number === ''){
        array_push($errMsg, "Не все поля заполнены!");
    } elseif (mb_strlen($title, 'UTF8') < 7){
        array_push($errMsg, "Название статьи должно быть более 7-ми символов");
    } else {
        $post = [
            'id_user' => $_SESSION['id'],
            'title' => $title,
            'content' => $content,
            'file' => $_POST['file'], // Заменено поле на file
            'status' => $publish,
            'id_topic' => $topic,
            'gmail' => $gmail, // Добавлено сохранение адреса Gmail
            'number' => $number // Добавлено сохранение номера телефона
        ];

        $post = insert('base', $post);
        $post = selectOne('base', ['id' => $id] );
        header('location: ' . BASE_URL . 'admin/base-zaiavoc/index.php');
    }
} else {
    $id = '';
    $title = '';
    $content = '';
    $publish = '';
    $topic = '';
    $gmail = ''; // Добавлено инициализация переменной для адреса Gmail
    $number = ''; // Добавлено инициализация переменной для номера телефона
}

// АПДЕЙТ СТАТЬИ
if($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])){
    $post = selectOne('base', ['id' => $_GET['id']]);

    $id =  $post['id'];
    $title =  $post['title'];
    $content = $post['content'];
    $topic = $post['id_topic'];
    $publish = $post['status'];
    $gmail = $post['gmail']; // Добавлено извлечение адреса Gmail
    $number = $post['number']; // Добавлено извлечение номера телефона
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_post'])){
    $id =  $_POST['id'];
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $topic = trim($_POST['topic']);
    $publish = isset($_POST['publish']) ? 1 : 0;
    $gmail = trim($_POST['gmail']); // Получение адреса Gmail из формы
    $number = trim($_POST['number']); // Получение номера телефона из формы

    // Логика загрузки файла (повторяется как для создания новой статьи)
}
if (!empty($_FILES['file']['name'])){ // Заменено поле на file
    $fileName = time() . "_" . $_FILES['file']['name']; // Заменено поле на file
    $fileTmpName = $_FILES['file']['tmp_name']; // Заменено поле на file
    $destination = ROOT_PATH . "/assets/files/" . $fileName; // Заменено поле на file

    $result = move_uploaded_file($fileTmpName, $destination); // Заменено поле на file

    if ($result){
        $_POST['file'] = $fileName; // Заменено поле на file
    } else {
        array_push($errMsg, "Ошибка загрузки файла на сервер");
    }
} else {
    // Если файл не выбран, установим значение пустой строки для file
    $_POST['file'] = ''; // Заменено поле на file
}

// Статус опубликовать или снять с публикации
if($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['pub_id'])){
    $id = $_GET['pub_id'];
    $publish = $_GET['publish'];

    $postId = update('base', $id, ['status' => $publish]);

    header('location: ' . BASE_URL . 'admin/base-zaiavoc/index.php');
    exit();
}

// Удаление статьи
if($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['delete_id'])){
    $id = $_GET['delete_id'];
    delete('base', $id);
    header('location: ' . BASE_URL . 'admin/base-zaiavoc/index.php');
}
?>